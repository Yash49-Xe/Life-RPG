# Finish Life RPG Premium Frontend

## Scope
Complete the uploaded Life RPG frontend in its existing dark-fantasy, voxel-inspired visual direction.

## Changes
- Import the uploaded source and artwork without copying repository metadata or generated files.
- Rebuild the Quest Board to match the blocky glass-panel design used across Dashboard, Village, Character, and Guild.
- Complete task verification states:
  - Study quests require a running focus timer.
  - Exercise quests require an image preview before completion.
  - Gym quests require a successful browser-location check.
  - Work and Personal quests retain clear honor confirmation.
- Add the gem balance beside coins and level in the shared navigation header.
- Add a dismissible level-up celebration with reduced-motion support and accessible announcement behavior.
- Tighten shared mobile navigation and ensure controls, dialogs, progress indicators, and text remain usable at phone widths.
- Preserve centralized demo state and ensure task completion immediately updates XP, coins, streaks, quests, and building XP.

## Validation
- Check all five routes for rendering and browser errors.
- Exercise key interactions: filtering, task creation/completion, each verification path, upgrades/rush, quest claims, and guild forms.
- Verify representative desktop and mobile layouts with screenshots.
- Confirm every route retains unique metadata and no external image hotlinks are introduced.

## Technical Notes
- Keep TanStack Start, React 19, Tailwind CSS v4, Motion, and the existing semantic OKLCH token system.
- Reuse the existing design-system Button and dialog patterns; avoid new backend or persistence work.
- Keep demo data in the shared game provider so documented API calls can replace actions later.
