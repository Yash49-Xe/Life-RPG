import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, Dumbbell, Hammer, Palette, Shield, Sparkles, Zap } from "lucide-react";
import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import {
  buildingXpRequired,
  formatDuration,
  rushCost,
  upgradeCost,
  upgradeSeconds,
  useGame,
  type BuildingId,
} from "@/lib/game";
import villageAsset from "@/assets/life-rpg-village.jpg.asset.json";

export const Route = createFileRoute("/buildings")({
  head: () => ({
    meta: [
      { title: "My Village — Life RPG" },
      {
        name: "description",
        content: "Upgrade village buildings, manage the builder queue, and rush construction with coins.",
      },
      { property: "og:title", content: "My Village — Life RPG" },
      {
        property: "og:description",
        content: "Upgrade your fantasy village tier by tier and unlock powerful bonuses.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Buildings,
});

const icons: Record<BuildingId, typeof Dumbbell> = {
  gym: Dumbbell,
  library: BookOpen,
  guild: Shield,
  studio: Palette,
};

function Buildings() {
  const { buildings, builders, coins, now, startUpgrade, rushUpgrade } = useGame();
  const realmLevel = buildings.reduce((sum, building) => sum + building.level, 0);
  const busy = builders.filter((slot) => slot.buildingId).length;

  return (
    <div className="space-y-6">
      <section className="relative min-h-[360px] overflow-hidden border-2 border-border">
        <img
          src={villageAsset.url}
          alt="Isometric view of Kael's blocky village at night"
          width={1600}
          height={900}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 pixel-grid bg-gradient-to-t from-background via-background/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 flex flex-wrap items-end justify-between gap-4 p-6">
          <div className="min-w-0">
            <p className="game-label text-primary">Village hall level {realmLevel}</p>
            <h2 className="panel-title mt-2 text-xl sm:text-2xl">Moonfall Haven</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Four districts · {busy}/{builders.length} builders working
            </p>
          </div>
          <div className="glass-panel hidden p-3 text-right sm:block">
            <p className="game-label">Realm power</p>
            <p className="panel-title mt-2 text-base text-primary">{(realmLevel * 766).toLocaleString()}</p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        {builders.map((slot) => {
          const building = buildings.find((item) => item.id === slot.buildingId);
          const msLeft = Math.max(0, slot.endsAt - now);
          const pct = slot.totalMs ? Math.min(100, ((slot.totalMs - msLeft) / slot.totalMs) * 100) : 0;
          const cost = rushCost(msLeft);
          return (
            <article key={slot.id} className="glass-panel p-5">
              <div className="flex items-center gap-3">
                <div
                  className={`block-raised p-3 ${building ? "bg-reward/10 text-reward block-bob" : "bg-muted text-muted-foreground"}`}
                >
                  <Hammer />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="game-label">Builder {slot.id}</p>
                  <h3 className="truncate text-sm font-bold">
                    {building ? `${building.name} → Level ${building.level + 1}` : "Idle and ready for work"}
                  </h3>
                </div>
                {building && <span className="panel-title text-[.6rem] text-reward">{formatDuration(msLeft)}</span>}
              </div>
              <div className="progress-track mt-4">
                <motion.div
                  className="h-full bg-reward"
                  initial={false}
                  animate={{ width: `${building ? pct : 0}%` }}
                  transition={{ duration: 0.4 }}
                />
              </div>
              <Button
                variant="reward"
                className="mt-4 w-full"
                disabled={!building}
                onClick={() => rushUpgrade(slot.id)}
              >
                <Zap /> {building ? `Rush for ${cost} coins` : "No job in progress"}
              </Button>
              {building && coins < cost && (
                <p className="mt-2 text-xs text-destructive">You need {cost - coins} more coins to rush.</p>
              )}
            </article>
          );
        })}
      </section>

      <section>
        <div className="mb-4">
          <p className="game-label">Districts</p>
          <h2 className="panel-title mt-2 text-lg">Village buildings</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {buildings.map((building) => {
            const Icon = icons[building.id];
            const needed = buildingXpRequired(building.level);
            const ready = building.xp >= needed;
            const cost = upgradeCost(building.level);
            const inProgress = builders.some((slot) => slot.buildingId === building.id);
            const freeBuilder = builders.some((slot) => !slot.buildingId);
            const tier = building.tierNames[Math.min(building.level, building.tierNames.length - 1)];
            return (
              <motion.article whileHover={{ y: -3 }} key={building.id} className="glass-panel p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 gap-3">
                    <div className="block-raised shrink-0 bg-primary/10 p-3 text-primary">
                      <Icon />
                    </div>
                    <div className="min-w-0">
                      <h3 className="panel-title text-[.7rem]">{building.name}</h3>
                      <p className="mt-2 text-xs text-muted-foreground">
                        {tier} · Level {building.level}
                      </p>
                    </div>
                  </div>
                  {inProgress ? (
                    <span className="block-raised bg-reward/10 px-2 py-1 text-[10px] font-bold text-reward">
                      BUILDING
                    </span>
                  ) : ready ? (
                    <span className="block-raised bg-success/10 px-2 py-1 text-[10px] font-bold text-success">
                      READY
                    </span>
                  ) : null}
                </div>

                <div className="mt-6">
                  <div className="mb-2 flex justify-between text-xs">
                    <span className="text-muted-foreground">Building XP</span>
                    <span className={ready ? "text-success" : "text-primary"}>
                      {building.xp}/{needed}
                    </span>
                  </div>
                  <div className="progress-track">
                    <motion.div
                      className={`h-full ${ready ? "bg-success" : "progress-fill"}`}
                      initial={false}
                      animate={{ width: `${Math.min(100, (building.xp / needed) * 100)}%` }}
                    />
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground">{building.perk}</p>
                  <dl className="mt-4 grid grid-cols-2 gap-2 text-xs">
                    <div className="block-inset bg-muted/40 p-2">
                      <dt className="game-label">Upgrade cost</dt>
                      <dd className="mt-1 font-bold text-reward">{cost} coins</dd>
                    </div>
                    <div className="block-inset bg-muted/40 p-2">
                      <dt className="game-label">Build time</dt>
                      <dd className="mt-1 font-bold text-foreground">
                        {formatDuration(upgradeSeconds(building.level) * 1000)}
                      </dd>
                    </div>
                  </dl>
                </div>

                <Button
                  variant={ready && !inProgress && freeBuilder && coins >= cost ? "game" : "outline"}
                  className="mt-5 w-full"
                  disabled={!ready || inProgress}
                  onClick={() => startUpgrade(building.id)}
                >
                  <Sparkles />
                  {inProgress
                    ? "Under construction"
                    : !ready
                      ? `Earn ${needed - building.xp} more XP`
                      : !freeBuilder
                        ? "All builders busy"
                        : coins < cost
                          ? `Need ${cost} coins`
                          : "Upgrade now"}
                </Button>
              </motion.article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
