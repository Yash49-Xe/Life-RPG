import { createFileRoute } from "@tanstack/react-router";
import { Brain, Coins, Dumbbell, Flame, Heart, Sparkles, Target } from "lucide-react";
import { motion } from "motion/react";
import { useGame, xpRequired, type Category } from "@/lib/game";
import avatarAsset from "@/assets/ranger-avatar.jpg.asset.json";
import villageAsset from "@/assets/life-rpg-village.jpg.asset.json";

export const Route = createFileRoute("/character")({
  head: () => ({
    meta: [
      { title: "Character — Life RPG" },
      {
        name: "description",
        content: "Review Kael's level progression, XP formula, stat grid, and category-derived attributes.",
      },
      { property: "og:title", content: "Character — Life RPG" },
      {
        property: "og:description",
        content: "Level progression, XP formula, and attributes earned from your real-life categories.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CharacterPage,
});

const attributeMap: { label: string; from: Category; icon: typeof Brain; color: string }[] = [
  { label: "Intelligence", from: "Study", icon: Brain, color: "text-primary" },
  { label: "Strength", from: "Gym", icon: Dumbbell, color: "text-destructive" },
  { label: "Endurance", from: "Exercise", icon: Heart, color: "text-success" },
  { label: "Discipline", from: "Work", icon: Target, color: "text-accent" },
  { label: "Creativity", from: "Personal", icon: Sparkles, color: "text-reward" },
];

function CharacterPage() {
  const { level, xp, coins, gems, streaks, tasks, buildings } = useGame();
  const needed = xpRequired(level);
  const pct = Math.min(100, (xp / needed) * 100);
  const completed = tasks.filter((task) => task.done).length;

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden border-2 border-border">
        <img
          src={villageAsset.url}
          alt="Village skyline behind the character sheet"
          width={1600}
          height={900}
          className="absolute inset-0 h-full w-full object-cover opacity-35"
        />
        <div className="absolute inset-0 pixel-grid bg-gradient-to-t from-background via-background/70 to-background/30" />
        <div className="relative grid gap-6 p-6 sm:p-8 lg:grid-cols-[auto_1fr] lg:items-center">
          <div className="flex items-center gap-4">
            <div className="relative shrink-0">
              <img
                src={avatarAsset.url}
                alt="Kael the ranger"
                width={768}
                height={768}
                className="h-28 w-28 border-4 border-primary object-cover shadow-glow"
              />
              <span className="absolute -bottom-3 -right-3 level-chip">LVL {level}</span>
            </div>
            <div className="min-w-0">
              <p className="game-label text-primary">Ranger class</p>
              <h2 className="panel-title mt-2 text-base sm:text-xl">Kael the Pathfinder</h2>
              <p className="mt-2 text-sm text-muted-foreground">{completed} quests cleared this season</p>
            </div>
          </div>
          <div className="glass-panel p-5">
            <div className="mb-2 flex flex-wrap justify-between gap-2 text-xs">
              <span className="font-bold">EXPERIENCE</span>
              <span className="text-primary">
                {xp.toLocaleString()} / {needed.toLocaleString()} XP
              </span>
            </div>
            <div className="progress-track h-4">
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} className="progress-fill" />
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              XP needed for a level is <code className="text-primary">floor(100 × level^1.5)</code>. Level {level}{" "}
              costs {needed.toLocaleString()} XP; level {level + 1} will cost {xpRequired(level + 1).toLocaleString()}{" "}
              XP.
            </p>
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Coins", value: coins, icon: Coins, tone: "text-reward" },
          { label: "Gems", value: gems, icon: Sparkles, tone: "text-elixir" },
          { label: "Best streak", value: Math.max(...Object.values(streaks)), icon: Flame, tone: "text-primary" },
          {
            label: "Village tiers",
            value: buildings.reduce((sum, item) => sum + item.level, 0),
            icon: Target,
            tone: "text-success",
          },
        ].map(({ label, value, icon: Icon, tone }) => (
          <article key={label} className="glass-panel p-5">
            <div className="flex items-center justify-between">
              <p className="game-label">{label}</p>
              <Icon className={tone} />
            </div>
            <p className="panel-title mt-4 text-base">{value}</p>
          </article>
        ))}
      </section>

      <section>
        <div className="mb-4">
          <p className="game-label">Derived from your categories</p>
          <h2 className="panel-title mt-2 text-base">Attributes</h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {attributeMap.map(({ label, from, icon: Icon, color }) => {
            const streak = streaks[from] ?? 0;
            const building = buildings.find((item) => item.category === from);
            const score = 10 + streak * 3 + (building ? building.level * 4 : 0);
            return (
              <motion.article whileHover={{ y: -3 }} key={label} className="glass-panel p-5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="block-raised shrink-0 bg-muted/50 p-3">
                      <Icon className={color} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="truncate text-sm font-bold">{label}</h3>
                      <p className="text-xs text-muted-foreground">
                        {from} streak {streak} · {building?.name ?? "No building"}
                      </p>
                    </div>
                  </div>
                  <span className="panel-title text-[.7rem] text-primary">{score}</span>
                </div>
                <div className="progress-track mt-4">
                  <motion.div
                    className="progress-fill"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, score)}%` }}
                  />
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
