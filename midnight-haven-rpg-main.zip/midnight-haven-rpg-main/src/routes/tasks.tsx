import { createFileRoute } from "@tanstack/react-router";
import { Camera, Check, Clock3, Coins, LocateFixed, Plus, ScrollText, Sparkles, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { coinsForTask, type Category, type GameTask, useGame } from "@/lib/game";

export const Route = createFileRoute("/tasks")({
  head: () => ({
    meta: [
      { title: "Quest Board — Life RPG" },
      { name: "description", content: "Create and complete verified daily quests to earn XP and coins." },
      { property: "og:title", content: "Quest Board — Life RPG" },
      { property: "og:description", content: "Complete focus, fitness, work, and personal quests." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Tasks,
});

const categories = ["All", "Study", "Exercise", "Gym", "Work", "Personal"] as const;

const verificationLabel = (category: Category) => {
  if (category === "Study") return "Focus timer verification";
  if (category === "Exercise") return "Photo verification";
  if (category === "Gym") return "Location verification";
  return "Honor verification";
};

function Tasks() {
  const { tasks, completeTask, addTask, streaks } = useGame();
  const [filter, setFilter] = useState<(typeof categories)[number]>("All");
  const [selected, setSelected] = useState<GameTask | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<Category>("Study");
  const visible = filter === "All" ? tasks : tasks.filter((task) => task.category === filter);
  const openCount = tasks.filter((task) => !task.done).length;

  return (
    <div className="space-y-6">
      <section className="glass-panel overflow-hidden">
        <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[1fr_minmax(420px_.9fr)] lg:items-end">
          <div>
            <div className="flex items-center gap-3">
              <div className="block-raised bg-primary/10 p-3 text-primary"><ScrollText /></div>
              <div><p className="game-label text-primary">Adventurer's ledger</p><h2 className="panel-title mt-2 text-base sm:text-xl">Quest Board</h2></div>
            </div>
            <p className="mt-4 max-w-xl text-sm text-muted-foreground">Every completed quest strengthens your character, streaks, and matching village district.</p>
            <div className="mt-5 flex gap-5 text-xs"><span><strong className="text-primary">{openCount}</strong> active</span><span><strong className="text-success">{tasks.length - openCount}</strong> cleared</span></div>
          </div>
          <form className="block-inset grid gap-3 bg-muted/30 p-4 sm:grid-cols-[minmax(0,1fr)_auto_auto]" onSubmit={(event) => { event.preventDefault(); if (title.trim()) { addTask(title.trim(), category); setTitle(""); } }}>
            <label className="sr-only" htmlFor="quest-title">Quest title</label>
            <input id="quest-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Name a new quest..." className="h-10 min-w-0 border-2 border-input bg-card px-3 text-sm" />
            <label className="sr-only" htmlFor="quest-category">Quest category</label>
            <select id="quest-category" value={category} onChange={(event) => setCategory(event.target.value as Category)} className="h-10 border-2 border-input bg-card px-3 text-sm"><option>Study</option><option>Exercise</option><option>Gym</option><option>Work</option><option>Personal</option></select>
            <Button variant="game" type="submit"><Plus /> Add quest</Button>
          </form>
        </div>
      </section>

      <div className="flex gap-2 overflow-x-auto pb-2" aria-label="Filter quests">
        {categories.map((item) => <Button key={item} size="sm" variant={filter === item ? "game" : "outline"} aria-pressed={filter === item} onClick={() => setFilter(item)}>{item}</Button>)}
      </div>

      <section className="grid gap-3">
        <AnimatePresence mode="popLayout">
          {visible.map((task, index) => {
            const reward = coinsForTask(task.xp, streaks[task.category]);
            return (
              <motion.article layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ delay: index * 0.035 }} key={task.id} className={`glass-panel grid gap-4 p-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center ${task.done ? "opacity-60" : ""}`}>
                <Button variant="ghost" size="icon" disabled={task.done} onClick={() => setSelected(task)} aria-label={task.done ? `${task.title} completed` : `Complete ${task.title}`} className={`block-raised h-12 w-12 ${task.done ? "bg-success/10 text-success" : "bg-primary/10 text-primary"}`}>{task.done ? <Check /> : <Sparkles />}</Button>
                <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className={`font-bold ${task.done ? "line-through" : ""}`}>{task.title}</h3><span className="block-inset bg-muted px-2 py-1 text-[10px] font-bold uppercase text-muted-foreground">{task.category}</span></div><p className="mt-1 text-xs text-muted-foreground">{verificationLabel(task.category)}</p></div>
                <div className="flex flex-wrap items-center justify-between gap-3 sm:justify-end"><span className="panel-title text-[.6rem] text-primary">+{task.xp} XP</span><span className="flex items-center gap-1 text-xs font-bold text-reward"><Coins className="h-4 w-4" />+{reward}</span>{!task.done && <Button variant="game" onClick={() => setSelected(task)}>Verify quest</Button>}</div>
              </motion.article>
            );
          })}
        </AnimatePresence>
        {visible.length === 0 && <div className="glass-panel p-8 text-center text-sm text-muted-foreground">No quests in this category yet.</div>}
      </section>

      <AnimatePresence>{selected && <VerificationModal task={selected} close={() => setSelected(null)} finish={() => { completeTask(selected.id); setSelected(null); }} />}</AnimatePresence>
    </div>
  );
}

function VerificationModal({ task, close, finish }: { task: GameTask; close: () => void; finish: () => void }) {
  const [elapsed, setElapsed] = useState(0);
  const [started, setStarted] = useState(false);
  const [preview, setPreview] = useState("");
  const [location, setLocation] = useState<"idle" | "checking" | "verified" | "error">("idle");
  const objectUrl = useRef("");

  useEffect(() => {
    if (!started || elapsed >= 5) return;
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [started, elapsed]);

  useEffect(() => () => { if (objectUrl.current) URL.revokeObjectURL(objectUrl.current); }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") close(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [close]);

  const locate = () => {
    setLocation("checking");
    if (!navigator.geolocation) { setLocation("error"); return; }
    navigator.geolocation.getCurrentPosition(() => setLocation("verified"), () => setLocation("error"), { timeout: 8000 });
  };

  const canFinish = task.category === "Study" ? elapsed >= 5 : task.category === "Exercise" ? Boolean(preview) : task.category === "Gym" ? location === "verified" : true;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] flex items-center justify-center bg-overlay p-4" role="dialog" aria-modal="true" aria-labelledby="verify-title" onMouseDown={(event) => { if (event.target === event.currentTarget) close(); }}>
      <motion.div initial={{ scale: .94, y: 15 }} animate={{ scale: 1, y: 0 }} className="glass-panel w-full max-w-md p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3"><div><p className="game-label text-primary">Quest verification</p><h2 id="verify-title" className="panel-title mt-2 text-[.72rem]">{task.title}</h2></div><Button variant="ghost" size="icon" onClick={close} aria-label="Close verification"><X /></Button></div>

        {task.category === "Study" && <div className="py-8 text-center"><Clock3 className="mx-auto mb-3 h-9 w-9 text-primary" /><p className="panel-title text-3xl">00:{String(elapsed).padStart(2, "0")}</p><p className="mt-3 text-xs text-muted-foreground">Keep the focus session active for five seconds to verify this demo quest.</p>{elapsed < 5 && <Button variant="game" className="mt-5" disabled={started} onClick={() => setStarted(true)}>{started ? "Focus session active" : "Start focus session"}</Button>}{elapsed >= 5 && <p className="mt-5 text-sm font-bold text-success"><Check className="mr-1 inline h-4 w-4" />Focus verified</p>}</div>}

        {task.category === "Exercise" && <label className="my-6 flex min-h-48 cursor-pointer flex-col items-center justify-center border-2 border-dashed border-primary/50 bg-primary/5 p-4 text-center focus-within:outline focus-within:outline-2 focus-within:outline-ring"><Camera className="mb-3 text-primary" />{preview ? <img src={preview} alt="Exercise proof preview" className="max-h-36 object-contain" /> : <><strong>Choose your workout photo</strong><span className="mt-1 text-xs text-muted-foreground">A preview is required before collecting the reward.</span></>}<input type="file" accept="image/*" className="sr-only" onChange={(event) => { const file = event.target.files?.[0]; if (!file) return; if (objectUrl.current) URL.revokeObjectURL(objectUrl.current); objectUrl.current = URL.createObjectURL(file); setPreview(objectUrl.current); }} /></label>}

        {task.category === "Gym" && <div className="py-8 text-center"><LocateFixed className="mx-auto mb-3 h-10 w-10 text-primary" /><p className="text-sm text-muted-foreground">Confirm you are at your workout location using this device.</p><Button variant="game" className="mt-5" onClick={locate} disabled={location === "checking"}>{location === "checking" ? "Checking location..." : "Verify browser location"}</Button>{location === "verified" && <p className="mt-4 text-sm font-bold text-success"><Check className="mr-1 inline h-4 w-4" />Location verified</p>}{location === "error" && <p className="mt-4 text-sm text-destructive">Location could not be verified. Allow access and try again.</p>}</div>}

        {!(["Study", "Exercise", "Gym"] as Category[]).includes(task.category) && <div className="my-8 block-inset bg-muted/30 p-5 text-center"><Sparkles className="mx-auto mb-3 text-primary" /><p className="text-sm text-muted-foreground">Confirm this quest on your honor to collect its rewards.</p></div>}

        <Button variant="reward" className="w-full" disabled={!canFinish} onClick={finish}><Check />Verify & collect +{task.xp} XP</Button>
      </motion.div>
    </motion.div>
  );
}