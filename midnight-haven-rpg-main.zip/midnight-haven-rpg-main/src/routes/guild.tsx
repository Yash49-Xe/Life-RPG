import { createFileRoute } from "@tanstack/react-router";
import { Crown, DoorOpen, Medal, Shield, Users } from "lucide-react";
import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { useGame } from "@/lib/game";

export const Route = createFileRoute("/guild")({
  head: () => ({
    meta: [
      { title: "Guild Hall — Life RPG" },
      {
        name: "description",
        content: "Climb the global ranking, create or join a guild with a code, and compare member progress.",
      },
      { property: "og:title", content: "Guild Hall — Life RPG" },
      {
        property: "og:description",
        content: "Global rankings, podium standings, and guild membership for your Life RPG character.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GuildPage,
});

const globalRanks = [
  { name: "Seraphine", level: 24, xp: 51200 },
  { name: "Bramblefoot", level: 21, xp: 44120 },
  { name: "Kael", level: 12, xp: 31800 },
  { name: "Orrin Vale", level: 11, xp: 28740 },
  { name: "Nyx", level: 10, xp: 24110 },
  { name: "Tamsin", level: 9, xp: 21450 },
];

const guildMembers = [
  { name: "Kael", role: "Officer", weekly: 1420 },
  { name: "Orrin Vale", role: "Leader", weekly: 1810 },
  { name: "Nyx", role: "Member", weekly: 990 },
  { name: "Tamsin", role: "Member", weekly: 760 },
];

function GuildPage() {
  const { guild, level, createGuild, joinGuild, leaveGuild } = useGame();
  const [tab, setTab] = useState<"global" | "center">("global");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [status, setStatus] = useState<{ tone: "ok" | "error"; text: string } | null>(null);

  const podium = globalRanks.slice(0, 3);

  return (
    <div className="space-y-6">
      <section className="glass-panel p-6">
        <p className="game-label text-primary">Season 4 standings</p>
        <h2 className="panel-title mt-2 text-base sm:text-lg">Guild Hall</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Compete globally and pull your guild up the ladder with every completed quest.
        </p>
      </section>

      <div className="flex gap-2" role="tablist" aria-label="Guild views">
        {(["global", "center"] as const).map((item) => (
          <Button
            key={item}
            role="tab"
            aria-selected={tab === item}
            onClick={() => setTab(item)}
            variant="ghost"
            className={`tab-blocky ${tab === item ? "tab-blocky-active" : ""}`}
          >
            {item === "global" ? "Global ranking" : "Guild center"}
          </Button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {tab === "global" ? (
          <motion.section
            key="global"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="space-y-6"
          >
            <div className="grid gap-4 sm:grid-cols-3">
              {podium.map((player, index) => (
                <article
                  key={player.name}
                  className={`glass-panel p-5 text-center ${index === 0 ? "sm:order-2 sm:-translate-y-3" : index === 1 ? "sm:order-1" : "sm:order-3"}`}
                >
                  <div
                    className={`mx-auto block-raised w-fit p-3 ${index === 0 ? "bg-reward/15 text-reward" : "bg-muted/50 text-muted-foreground"}`}
                  >
                    {index === 0 ? <Crown /> : <Medal />}
                  </div>
                  <h3 className="panel-title mt-4 text-[.7rem]">{player.name}</h3>
                  <p className="mt-2 text-xs text-muted-foreground">Level {player.level}</p>
                  <p className="mt-1 text-sm font-bold text-primary">{player.xp.toLocaleString()} XP</p>
                </article>
              ))}
            </div>

            <ul className="glass-panel divide-y-2 divide-border">
              {globalRanks.map((player, index) => (
                <li
                  key={player.name}
                  className={`grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 p-4 ${player.name === "Kael" ? "bg-primary/10" : ""}`}
                >
                  <span className="panel-title w-8 text-[.65rem] text-muted-foreground">{index + 1}</span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold">{player.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Level {player.name === "Kael" ? level : player.level}
                    </p>
                  </div>
                  <span className="text-sm font-bold text-primary">{player.xp.toLocaleString()}</span>
                </li>
              ))}
            </ul>
          </motion.section>
        ) : (
          <motion.section
            key="center"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="grid gap-6 lg:grid-cols-[1fr_1fr]"
          >
            <div className="glass-panel p-5">
              <div className="flex items-center gap-3">
                <div className="block-raised bg-primary/10 p-3 text-primary">
                  <Shield />
                </div>
                <div className="min-w-0">
                  <p className="game-label">{guild.joined ? "Your guild" : "No guild yet"}</p>
                  <h3 className="panel-title mt-2 truncate text-[.7rem]">
                    {guild.joined ? guild.name : "Found or join one"}
                  </h3>
                </div>
              </div>

              {guild.joined ? (
                <>
                  <p className="mt-4 text-sm text-muted-foreground">
                    Invite code <strong className="text-primary">{guild.code}</strong>
                  </p>
                  <ul className="mt-4 divide-y-2 divide-border">
                    {guildMembers.map((member) => (
                      <li key={member.name} className="flex items-center justify-between gap-3 py-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-bold">{member.name}</p>
                          <p className="text-xs text-muted-foreground">{member.role}</p>
                        </div>
                        <span className="text-sm font-bold text-reward">{member.weekly} XP</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    variant="outline"
                    className="mt-5 w-full"
                    onClick={() => {
                      leaveGuild();
                      setStatus({ tone: "ok", text: "You left the guild." });
                    }}
                  >
                    <DoorOpen /> Leave guild
                  </Button>
                </>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">
                  Guild members share weekly XP goals and bonus coins.
                </p>
              )}
            </div>

            <div className="space-y-6">
              <form
                className="glass-panel space-y-3 p-5"
                onSubmit={(event) => {
                  event.preventDefault();
                  const ok = createGuild(name);
                  setStatus({
                    tone: ok ? "ok" : "error",
                    text: ok ? `Guild "${name.trim()}" founded.` : "Guild names need at least three characters.",
                  });
                  if (ok) setName("");
                }}
              >
                <div className="flex items-center gap-2">
                  <Users className="text-primary" />
                  <h3 className="panel-title text-[.7rem]">Create a guild</h3>
                </div>
                <label className="game-label block" htmlFor="guild-name">
                  Guild name
                </label>
                <input
                  id="guild-name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Moonfall Wardens"
                  className="h-11 w-full border-2 border-input bg-card px-3 text-sm"
                />
                <Button variant="game" className="w-full" type="submit">
                  Found guild
                </Button>
              </form>

              <form
                className="glass-panel space-y-3 p-5"
                onSubmit={(event) => {
                  event.preventDefault();
                  const ok = joinGuild(code);
                  setStatus({
                    tone: ok ? "ok" : "error",
                    text: ok ? `Joined with code ${code.toUpperCase()}.` : "That code should look like AB-1234.",
                  });
                  if (ok) setCode("");
                }}
              >
                <div className="flex items-center gap-2">
                  <Shield className="text-reward" />
                  <h3 className="panel-title text-[.7rem]">Join with a code</h3>
                </div>
                <label className="game-label block" htmlFor="guild-code">
                  Invite code
                </label>
                <input
                  id="guild-code"
                  value={code}
                  onChange={(event) => setCode(event.target.value)}
                  placeholder="MW-4821"
                  className="h-11 w-full border-2 border-input bg-card px-3 text-sm uppercase"
                />
                <Button variant="reward" className="w-full" type="submit">
                  Join guild
                </Button>
              </form>

              {status && (
                <p
                  role="status"
                  className={`block-inset p-3 text-sm ${status.tone === "ok" ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}
                >
                  {status.text}
                </p>
              )}
            </div>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}
