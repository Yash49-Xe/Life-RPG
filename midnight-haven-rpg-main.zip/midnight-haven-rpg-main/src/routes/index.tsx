import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpen,
  Check,
  Flame,
  Gift,
  Hammer,
  Palette,
  ShieldCheck,
  Snowflake,
  Swords,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import {
  formatDuration,
  rushCost,
  useGame,
  xpRequired,
  type Category,
} from "@/lib/game";
import villageAsset from "@/assets/life-rpg-village.jpg.asset.json";
import avatarAsset from "@/assets/ranger-avatar.jpg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Command Center — Life RPG" },
      {
        name: "description",
        content: "Track quests, XP, streaks, coins, and village construction from your Life RPG command center.",
      },
      { property: "og:title", content: "Command Center — Life RPG" },
      {
        property: "og:description",
        content: "Track quests, XP, streaks, coins, and village construction from your Life RPG command center.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const streakIcons: Partial<Record<Category, typeof BookOpen>> = {
  Study: BookOpen,
  Exercise: Swords,
  Work: ShieldCheck,
  Personal: Palette,
};

function Dashboard() {
  const {
    level,
    xp,
    tasks,
    buildings,
    builders,
    streaks,
    freezes,
    quests,
    coins,
    now,
    claimQuest,
    useFreeze,
    rushUpgrade,
  } = useGame();

  const total = xpRequired(level);
  const progress = Math.min(100, (xp / total) * 100);
  const openQuests = tasks.filter((task) => !task.done).slice(0, 3);
  const activeSlot = builders.find((slot) => slot.buildingId);
  const activeBuilding = buildings.find((item) => item.id === activeSlot?.buildingId);
  const msLeft = activeSlot ? Math.max(0, activeSlot.endsAt - now) : 0;
  const buildPct = activeSlot?.totalMs
    ? Math.min(100, ((activeSlot.totalMs - msLeft) / activeSlot.totalMs) * 100)
    : 0;
  const rush = rushCost(msLeft);

  return (
    <div className="space-y-6">
      <section className="relative min-h-[390px] overflow-hidden border-2 border-border">
        <img
           src={villageAsset.url}
          alt="Kael's moonlit blocky fantasy village"
          width={1600}
          height={900}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 pixel-grid bg-gradient-to-r from-background via-background/80 to-background/15" />
        <div className="relative z-10 flex min-h-[390px] max-w-xl flex-col justify-end p-6 sm:p-9">
          <div className="mb-5 flex items-center gap-4">
            <div className="relative shrink-0">
              <img
                 src={avatarAsset.url}
                alt="Kael the ranger"
                width={768}
                height={768}
                className="h-20 w-20 border-4 border-primary object-cover shadow-glow"
              />
              <span className="absolute -bottom-2 -right-2 level-chip">{level}</span>
            </div>
            <div className="min-w-0">
              <p className="game-label text-primary">Welcome back, adventurer</p>
              <h2 className="panel-title mt-2 text-base sm:text-xl">Kael the Pathfinder</h2>
              <p className="mt-2 text-sm text-muted-foreground">Your realm grew stronger while you were away.</p>
            </div>
          </div>
          <div className="glass-panel p-4">
            <div className="mb-2 flex flex-wrap justify-between gap-2 text-xs">
              <span className="font-bold">LEVEL {level} PROGRESS</span>
              <span className="text-primary">
                {xp.toLocaleString()} / {total.toLocaleString()} XP
              </span>
            </div>
            <div className="progress-track h-4">
              <motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }} className="progress-fill" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {(total - xp).toLocaleString()} XP until your next evolution
            </p>
          </div>
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.45fr_.9fr]">
        <div className="space-y-6">
          <section className="glass-panel overflow-hidden">
            <div className="flex items-center justify-between gap-3 border-b-2 border-border p-5">
              <div className="min-w-0">
                <p className="game-label">
                  Builder queue · {builders.filter((slot) => slot.buildingId).length}/{builders.length} active
                </p>
                <h2 className="panel-title mt-2 truncate text-[.7rem]">
                  {activeBuilding ? `${activeBuilding.name} · Level ${activeBuilding.level + 1}` : "All builders idle"}
                </h2>
              </div>
              <div className="block-raised bg-reward/10 p-2 text-reward">
                <Hammer />
              </div>
            </div>
            <div className="grid gap-5 p-5 sm:grid-cols-[1fr_auto] sm:items-end">
              <div>
                <div className="mb-2 flex flex-wrap justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">
                    {activeBuilding ? "Construction in progress" : "Start an upgrade in the village"}
                  </span>
                  <strong className="panel-title text-[.7rem] text-reward">{formatDuration(msLeft)}</strong>
                </div>
                <div className="progress-track">
                  <motion.div className="h-full bg-reward" initial={false} animate={{ width: `${buildPct}%` }} />
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  {activeBuilding ? activeBuilding.perk : "Every building boosts a matching stat."}
                </p>
              </div>
              <Button
                variant="reward"
                disabled={!activeSlot || coins < rush}
                onClick={() => activeSlot && rushUpgrade(activeSlot.id)}
              >
                <Zap /> {activeSlot ? `Rush · ${rush}` : "Idle"}
              </Button>
            </div>
          </section>

          <section>
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="game-label">Momentum</p>
                <h2 className="panel-title mt-2 text-base">Category streaks</h2>
              </div>
              <span className="text-xs text-muted-foreground">{freezes} streak freezes left</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {(["Study", "Exercise", "Work"] as Category[]).map((name) => {
                const Icon = streakIcons[name] ?? Flame;
                const days = streaks[name] ?? 0;
                return (
                  <motion.article whileHover={{ y: -3 }} key={name} className="glass-panel p-4">
                    <div className="flex items-center justify-between">
                      <Icon className="text-primary" />
                      <span className="block-raised bg-success/10 px-2 py-1 text-[10px] font-bold text-success">
                        BONUS ACTIVE
                      </span>
                    </div>
                    <div className="mt-5 flex items-end gap-2">
                      <strong className="panel-title text-lg">{days}</strong>
                      <span className="mb-1 text-xs text-muted-foreground">day {name} streak</span>
                    </div>
                    <div className="mt-3 flex gap-1">
                      {Array.from({ length: 7 }).map((_, i) => (
                        <span
                          key={i}
                          className={`h-2 flex-1 ${i < Math.min(days, 7) ? "bg-primary" : "bg-muted"}`}
                        />
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-4 w-full"
                      disabled={freezes === 0}
                      onClick={() => useFreeze(name)}
                    >
                      <Snowflake /> {freezes === 0 ? "No freezes" : "Freeze streak"}
                    </Button>
                  </motion.article>
                );
              })}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <section className="glass-panel flex flex-col">
            <div className="flex items-center justify-between border-b-2 border-border p-5">
              <div>
                <p className="game-label">Resets in 08:42:19</p>
                <h2 className="panel-title mt-2 text-[.7rem]">Daily quests</h2>
              </div>
              <Flame className="text-reward" />
            </div>
            <ul className="space-y-3 p-5">
              {quests.map((quest) => {
                const ready = quest.progress >= quest.goal && !quest.claimed;
                return (
                  <li key={quest.id} className="block-inset bg-muted/30 p-3">
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className="font-semibold">{quest.label}</span>
                      <span className="text-xs text-reward">+{quest.reward}</span>
                    </div>
                    <div className="progress-track mt-2">
                      <motion.div
                        className="h-full bg-success"
                        initial={false}
                        animate={{ width: `${Math.min(100, (quest.progress / quest.goal) * 100)}%` }}
                      />
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2">
                      <span className="text-xs text-muted-foreground">
                        {Math.min(quest.progress, quest.goal)}/{quest.goal}
                      </span>
                      <Button
                        size="sm"
                        variant={ready ? "reward" : "outline"}
                        disabled={!ready}
                        onClick={() => claimQuest(quest.id)}
                      >
                        {quest.claimed ? <Check /> : <Gift />} {quest.claimed ? "Claimed" : "Claim"}
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>

          <section className="glass-panel">
            <div className="flex items-center justify-between border-b-2 border-border p-5">
              <h2 className="panel-title text-[.7rem]">Next up</h2>
              <Link to="/tasks" className="flex items-center gap-1 text-xs text-primary">
                Quest board <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <ul className="divide-y-2 divide-border">
              {openQuests.map((task) => (
                <li key={task.id} className="flex items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{task.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {task.category} · +{task.xp} XP
                    </p>
                  </div>
                   <Button size="sm" variant="game" asChild>
                     <Link to="/tasks" aria-label={`Verify ${task.title}`}><Check /></Link>
                   </Button>
                </li>
              ))}
              {openQuests.length === 0 && (
                <li className="p-4 text-sm text-muted-foreground">Every quest is done. Add a new one.</li>
              )}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
