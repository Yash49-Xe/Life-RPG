import { Link, useRouterState } from "@tanstack/react-router";
import { Castle, CheckSquare2, Home, Menu, Shield, Sparkles, UserRound, X, Coins, Gem, Trophy } from "lucide-react";
import { useState, type ReactNode } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Button } from "@/components/ui/button";
import { GameProvider, useGame } from "@/lib/game";
import avatarAsset from "@/assets/ranger-avatar.jpg.asset.json";

const links = [
  { to: "/", label: "Command Center", icon: Home },
  { to: "/tasks", label: "Quest Board", icon: CheckSquare2 },
  { to: "/buildings", label: "My Village", icon: Castle },
  { to: "/character", label: "Character", icon: UserRound },
  { to: "/guild", label: "Guild Hall", icon: Shield },
] as const;

function ShellInner({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const reduceMotion = useReducedMotion();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const { level, xp, coins, gems, announcement, levelUp, dismissLevelUp } = useGame();
  const active = links.find((link) => link.to === pathname)?.label ?? "Life RPG";

  const nav = (
    <>
      <div className="flex h-20 items-center gap-3 border-b border-border px-5">
        <div className="brand-gem"><Sparkles /></div>
        <div><div className="font-display text-lg font-extrabold text-foreground">LIFE RPG</div><div className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Forge your legacy</div></div>
      </div>
      <nav className="flex-1 space-y-1 p-3" aria-label="Main navigation">
        {links.map(({ to, label, icon: Icon }) => (
          <Link key={to} to={to} onClick={() => setOpen(false)} className={`nav-item ${pathname === to ? "nav-item-active" : ""}`}><Icon /> <span>{label}</span>{pathname === to && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary shadow-glow" />}</Link>
        ))}
      </nav>
       <div className="m-3 glass-panel p-3">
         <div className="flex items-center gap-3"><img src={avatarAsset.url} alt="Kael the ranger" className="h-10 w-10 object-cover ring-1 ring-primary/50" /><div className="min-w-0"><p className="truncate text-sm font-bold">Kael</p><p className="text-xs text-muted-foreground">Level {level} Ranger</p></div></div>
         <div className="progress-track mt-3 h-1.5"><motion.div className="progress-fill" initial={false} animate={{ width: `${Math.min(100, (xp / Math.floor(100 * Math.pow(level, 1.5))) * 100)}%` }} /></div>
      </div>
    </>
  );

  return <div className="min-h-screen bg-background text-foreground">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-border bg-sidebar/90 backdrop-blur-xl lg:flex lg:flex-col">{nav}</aside>
    <AnimatePresence>{open && <><motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-40 bg-overlay lg:hidden" onClick={() => setOpen(false)} /><motion.aside initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} className="fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-border bg-sidebar lg:hidden"><Button variant="ghost" size="icon" className="absolute right-2 top-5" onClick={() => setOpen(false)} aria-label="Close menu"><X /></Button>{nav}</motion.aside></>}</AnimatePresence>
    <div className="lg:pl-64">
      <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-background/80 px-4 backdrop-blur-xl sm:px-6 lg:px-8">
        <div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu /></Button><div><p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Realm / Overview</p><h1 className="font-display text-lg font-extrabold">{active}</h1></div></div>
         <div className="flex items-center gap-2"><div className="currency-chip" aria-label={`${coins} coins`}><Coins /> <strong>{coins}</strong><span className="hidden md:inline">coins</span></div><div className="gem-chip" aria-label={`${gems} gems`}><Gem /> <strong>{gems}</strong><span className="hidden md:inline">gems</span></div><div className="level-chip hidden sm:flex">LVL {level}</div></div>
      </header>
       <main className="mx-auto max-w-[1500px] p-4 pb-24 sm:p-6 sm:pb-24 lg:p-8">{children}</main>
    </div>
     <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t-2 border-border bg-sidebar/95 backdrop-blur-xl lg:hidden" aria-label="Mobile navigation">
       {links.map(({ to, label, icon: Icon }) => <Link key={to} to={to} className={`flex min-h-16 flex-col items-center justify-center gap-1 px-1 text-[9px] font-bold uppercase ${pathname === to ? "bg-primary/10 text-primary" : "text-muted-foreground"}`} aria-label={label}><Icon className="h-5 w-5"/><span className="max-w-full truncate">{label.replace("Command Center", "Home").replace("Quest Board", "Quests").replace("My Village", "Village").replace("Guild Hall", "Guild")}</span></Link>)}
     </nav>
     <AnimatePresence>
       {levelUp && <motion.div initial={reduceMotion ? false : { opacity: 0, scale: .85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: .95 }} className="fixed inset-0 z-[70] flex items-center justify-center bg-overlay p-4" role="dialog" aria-modal="true" aria-labelledby="level-up-title">
         <div className="level-celebration glass-panel w-full max-w-md p-7 text-center">
           <Trophy className="mx-auto h-12 w-12 text-reward" />
           <p className="game-label mt-5 text-reward">New power unlocked</p>
           <h2 id="level-up-title" className="panel-title mt-3 text-xl">Level {levelUp}</h2>
           <p className="mt-3 text-sm text-muted-foreground">Your legend grows. Keep completing quests to strengthen the realm.</p>
           <Button variant="reward" className="mt-6 w-full" onClick={dismissLevelUp}>Continue the adventure</Button>
         </div>
       </motion.div>}
     </AnimatePresence>
    <div className="sr-only" aria-live="polite">{announcement}</div>
  </div>;
}

export function GameShell({ children }: { children: ReactNode }) { return <GameProvider><ShellInner>{children}</ShellInner></GameProvider>; }