import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type Category = "Study" | "Exercise" | "Gym" | "Work" | "Personal";

export type GameTask = {
  id: number;
  title: string;
  category: Category;
  xp: number;
  done: boolean;
};

export type BuildingId = "gym" | "library" | "guild" | "studio";

export type Building = {
  id: BuildingId;
  name: string;
  tierNames: string[];
  category: Category;
  level: number;
  xp: number;
  perk: string;
};

export type BuilderSlot = {
  id: number;
  buildingId: BuildingId | null;
  endsAt: number;
  totalMs: number;
};

export type DailyQuest = {
  id: number;
  label: string;
  goal: number;
  progress: number;
  reward: number;
  claimed: boolean;
};

export type GuildState = {
  joined: boolean;
  name: string;
  code: string;
};

/* ---------------------------------- formulas --------------------------------- */

export const xpRequired = (level: number) => Math.floor(100 * Math.pow(level, 1.5));
export const buildingXpRequired = (level: number) => Math.floor(120 * Math.pow(1.32, level));
export const upgradeCost = (level: number) => Math.floor(60 * Math.pow(1.45, level));
export const upgradeSeconds = (level: number) => 45 * level * level;
/** Clash-style rush pricing: the closer to done, the cheaper the rush. */
export const rushCost = (msLeft: number) => Math.max(1, Math.ceil(msLeft / 30000) * 2);
export const coinsForTask = (xp: number, streak: number) => 5 + Math.round(xp / 5) + Math.min(streak * 2, 20);

export const formatDuration = (ms: number) => {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}h ${pad(m)}m ${pad(s)}s` : `${pad(m)}:${pad(s)}`;
};

/* ----------------------------------- data ----------------------------------- */

const initialTasks: GameTask[] = [
  { id: 1, title: "Deep work: product roadmap", category: "Study", xp: 25, done: false },
  { id: 2, title: "Morning strength circuit", category: "Exercise", xp: 30, done: false },
  { id: 3, title: "Squat session at the arena", category: "Gym", xp: 35, done: false },
  { id: 4, title: "Ship the weekly report", category: "Work", xp: 20, done: true },
  { id: 5, title: "Sketch for 20 minutes", category: "Personal", xp: 15, done: false },
];

const initialBuildings: Building[] = [
  {
    id: "gym",
    name: "Training Grounds",
    tierNames: ["Dirt Pit", "Timber Yard", "Stone Arena", "Iron Colosseum", "Obsidian Forge"],
    category: "Gym",
    level: 3,
    xp: 226,
    perk: "+8 Strength and unlocks heavier gym quests",
  },
  {
    id: "library",
    name: "Grand Library",
    tierNames: ["Reading Nook", "Scroll Hut", "Stone Archive", "Arcane Academy", "Crystal Spire"],
    category: "Study",
    level: 4,
    xp: 422,
    perk: "+8 Intelligence and a new knowledge quest line",
  },
  {
    id: "guild",
    name: "Guild Office",
    tierNames: ["Tent", "Timber Hall", "Stone Manor", "Banner Keep", "Citadel"],
    category: "Work",
    level: 2,
    xp: 212,
    perk: "+6 Discipline and larger guild donations",
  },
  {
    id: "studio",
    name: "Art Studio",
    tierNames: ["Workbench", "Timber Atelier", "Glass Pavilion", "Muse Tower", "Aurora Gallery"],
    category: "Personal",
    level: 2,
    xp: 164,
    perk: "+6 Creativity and daily inspiration bonus",
  },
];

const initialQuests: DailyQuest[] = [
  { id: 1, label: "Complete 3 quests", goal: 3, progress: 1, reward: 40, claimed: false },
  { id: 2, label: "Earn 60 XP today", goal: 60, progress: 25, reward: 55, claimed: false },
  { id: 3, label: "Finish a verified gym quest", goal: 1, progress: 0, reward: 70, claimed: false },
];

const categoryOfTask: Record<Category, BuildingId> = {
  Study: "library",
  Exercise: "gym",
  Gym: "gym",
  Work: "guild",
  Personal: "studio",
};

/* ---------------------------------- context ---------------------------------- */

type GameContextValue = {
  now: number;
  level: number;
  xp: number;
  coins: number;
  gems: number;
  tasks: GameTask[];
  buildings: Building[];
  builders: BuilderSlot[];
  streaks: Record<Category, number>;
  freezes: number;
  quests: DailyQuest[];
  guild: GuildState;
  announcement: string;
  levelUp: number | null;
  dismissLevelUp: () => void;
  completeTask: (id: number) => void;
  addTask: (title: string, category: Category) => void;
  spendCoins: (amount: number, message: string) => boolean;
  startUpgrade: (id: BuildingId) => boolean;
  rushUpgrade: (slotId: number) => boolean;
  claimQuest: (id: number) => boolean;
  useFreeze: (category: Category) => boolean;
  createGuild: (name: string) => boolean;
  joinGuild: (code: string) => boolean;
  leaveGuild: () => void;
};

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const [now, setNow] = useState(() => Date.now());
  const [level, setLevel] = useState(12);
  const [xp, setXp] = useState(3180);
  const [coins, setCoins] = useState(284);
  const [gems, setGems] = useState(48);
  const [tasks, setTasks] = useState(initialTasks);
  const [buildings, setBuildings] = useState(initialBuildings);
  const [builders, setBuilders] = useState<BuilderSlot[]>([
    { id: 1, buildingId: "library", endsAt: Date.now() + 784_000, totalMs: 1_200_000 },
    { id: 2, buildingId: null, endsAt: 0, totalMs: 0 },
  ]);
  const [streaks, setStreaks] = useState<Record<Category, number>>({
    Study: 12,
    Exercise: 7,
    Gym: 4,
    Work: 5,
    Personal: 3,
  });
  const [freezes, setFreezes] = useState(2);
  const [quests, setQuests] = useState(initialQuests);
  const [guild, setGuild] = useState<GuildState>({ joined: true, name: "Moonfall Wardens", code: "MW-4821" });
  const [announcement, setAnnouncement] = useState("");
  const [levelUp, setLevelUp] = useState<number | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Finish builder jobs whose timers have elapsed.
  useEffect(() => {
    const finished = builders.filter((slot) => slot.buildingId && slot.endsAt <= now);
    if (finished.length === 0) return;
    setBuildings((current) =>
      current.map((building) =>
        finished.some((slot) => slot.buildingId === building.id)
          ? { ...building, level: building.level + 1, xp: 0 }
          : building,
      ),
    );
    setBuilders((current) =>
      current.map((slot) =>
        slot.buildingId && slot.endsAt <= now ? { ...slot, buildingId: null, endsAt: 0, totalMs: 0 } : slot,
      ),
    );
    const names = finished
      .map((slot) => buildings.find((building) => building.id === slot.buildingId)?.name)
      .filter(Boolean)
      .join(", ");
    setAnnouncement(`Construction complete: ${names}. The builder is free again.`);
  }, [now, builders, buildings]);

  const awardXp = useCallback(
    (amount: number) => {
      setXp((currentXp) => {
        let nextXp = currentXp + amount;
        setLevel((currentLevel) => {
          let nextLevel = currentLevel;
          while (nextXp >= xpRequired(nextLevel)) {
            nextXp -= xpRequired(nextLevel);
            nextLevel += 1;
          }
          if (nextLevel !== currentLevel) {
            setLevelUp(nextLevel);
            setAnnouncement(`Level up! You reached level ${nextLevel}.`);
          }
          return nextLevel;
        });
        return nextXp;
      });
    },
    [],
  );

  const completeTask = useCallback(
    (id: number) => {
      const task = tasks.find((item) => item.id === id);
      if (!task || task.done) return;
      const streak = streaks[task.category] ?? 0;
      const earnedCoins = coinsForTask(task.xp, streak);

      setTasks((current) => current.map((item) => (item.id === id ? { ...item, done: true } : item)));
      setCoins((value) => value + earnedCoins);
      setStreaks((current) => ({ ...current, [task.category]: (current[task.category] ?? 0) + 1 }));
      awardXp(task.xp);

      const target = categoryOfTask[task.category];
      setBuildings((current) =>
        current.map((building) =>
          building.id === target ? { ...building, xp: building.xp + task.xp } : building,
        ),
      );

      setQuests((current) =>
        current.map((quest) => {
          if (quest.claimed) return quest;
          if (quest.id === 1) return { ...quest, progress: Math.min(quest.goal, quest.progress + 1) };
          if (quest.id === 2) return { ...quest, progress: Math.min(quest.goal, quest.progress + task.xp) };
          if (quest.id === 3 && task.category === "Gym") return { ...quest, progress: 1 };
          return quest;
        }),
      );

      setAnnouncement(`${task.title} complete. Plus ${task.xp} XP and ${earnedCoins} coins.`);
    },
    [tasks, streaks, awardXp],
  );

  const addTask = useCallback((title: string, category: Category) => {
    const rewards: Record<Category, number> = { Study: 25, Exercise: 30, Gym: 35, Work: 20, Personal: 15 };
    setTasks((current) => [
      ...current,
      { id: Date.now(), title, category, xp: rewards[category], done: false },
    ]);
    setAnnouncement("New quest added to your board.");
  }, []);

  const spendCoins = useCallback(
    (amount: number, message: string) => {
      if (coins < amount) {
        setAnnouncement("Not enough coins for that action.");
        return false;
      }
      setCoins((value) => value - amount);
      setAnnouncement(message);
      return true;
    },
    [coins],
  );

  const startUpgrade = useCallback(
    (id: BuildingId) => {
      const building = buildings.find((item) => item.id === id);
      if (!building) return false;
      if (building.xp < buildingXpRequired(building.level)) {
        setAnnouncement(`${building.name} still needs more building XP.`);
        return false;
      }
      const free = builders.find((slot) => !slot.buildingId);
      if (!free) {
        setAnnouncement("Every builder is busy. Rush a job to free one.");
        return false;
      }
      const cost = upgradeCost(building.level);
      if (coins < cost) {
        setAnnouncement(`You need ${cost} coins to start that upgrade.`);
        return false;
      }
      const totalMs = upgradeSeconds(building.level) * 1000;
      setCoins((value) => value - cost);
      setBuilders((current) =>
        current.map((slot) =>
          slot.id === free.id ? { ...slot, buildingId: id, endsAt: Date.now() + totalMs, totalMs } : slot,
        ),
      );
      setAnnouncement(`${building.name} upgrade started. Builder ${free.id} is on the job.`);
      return true;
    },
    [buildings, builders, coins],
  );

  const rushUpgrade = useCallback(
    (slotId: number) => {
      const slot = builders.find((item) => item.id === slotId);
      if (!slot || !slot.buildingId) return false;
      const cost = rushCost(slot.endsAt - Date.now());
      if (coins < cost) {
        setAnnouncement(`Rushing costs ${cost} coins. Complete more quests first.`);
        return false;
      }
      setCoins((value) => value - cost);
      setBuilders((current) =>
        current.map((item) => (item.id === slotId ? { ...item, endsAt: Date.now() } : item)),
      );
      setAnnouncement("Construction rushed. The building is ready now.");
      return true;
    },
    [builders, coins],
  );

  const claimQuest = useCallback(
    (id: number) => {
      const quest = quests.find((item) => item.id === id);
      if (!quest || quest.claimed || quest.progress < quest.goal) {
        setAnnouncement("That daily quest is not ready to claim yet.");
        return false;
      }
      setQuests((current) => current.map((item) => (item.id === id ? { ...item, claimed: true } : item)));
      setCoins((value) => value + quest.reward);
      setGems((value) => value + 2);
      setAnnouncement(`Daily quest claimed. Plus ${quest.reward} coins and 2 gems.`);
      return true;
    },
    [quests],
  );

  const useFreeze = useCallback(
    (category: Category) => {
      if (freezes <= 0) {
        setAnnouncement("No streak freezes left today.");
        return false;
      }
      setFreezes((value) => value - 1);
      setAnnouncement(`${category} streak frozen. It survives one missed day.`);
      return true;
    },
    [freezes],
  );

  const createGuild = useCallback((name: string) => {
    if (name.trim().length < 3) {
      setAnnouncement("Guild names need at least three characters.");
      return false;
    }
    const code = `${name.trim().slice(0, 2).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setGuild({ joined: true, name: name.trim(), code });
    setAnnouncement(`Guild ${name.trim()} founded. Invite code ${code}.`);
    return true;
  }, []);

  const joinGuild = useCallback((code: string) => {
    if (!/^[A-Za-z]{2}-\d{4}$/.test(code.trim())) {
      setAnnouncement("That join code looks wrong. Use the AB-1234 format.");
      return false;
    }
    setGuild({ joined: true, name: "Moonfall Wardens", code: code.trim().toUpperCase() });
    setAnnouncement(`Joined guild with code ${code.trim().toUpperCase()}.`);
    return true;
  }, []);

  const leaveGuild = useCallback(() => {
    setGuild({ joined: false, name: "", code: "" });
    setAnnouncement("You left your guild.");
  }, []);

  const dismissLevelUp = useCallback(() => setLevelUp(null), []);

  const value = useMemo(
    () => ({
      now,
      level,
      xp,
      coins,
      gems,
      tasks,
      buildings,
      builders,
      streaks,
      freezes,
      quests,
      guild,
      announcement,
      levelUp,
      dismissLevelUp,
      completeTask,
      addTask,
      spendCoins,
      startUpgrade,
      rushUpgrade,
      claimQuest,
      useFreeze,
      createGuild,
      joinGuild,
      leaveGuild,
    }),
    [
      now,
      level,
      xp,
      coins,
      gems,
      tasks,
      buildings,
      builders,
      streaks,
      freezes,
      quests,
      guild,
      announcement,
      levelUp,
      dismissLevelUp,
      completeTask,
      addTask,
      spendCoins,
      startUpgrade,
      rushUpgrade,
      claimQuest,
      useFreeze,
      createGuild,
      joinGuild,
      leaveGuild,
    ],
  );

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const value = useContext(GameContext);
  if (!value) throw new Error("useGame must be used within GameProvider");
  return value;
}

/** Simple standalone countdown used by focus timers and demo widgets. */
export function useCountdown(initialSeconds: number) {
  const [seconds, setSeconds] = useState(initialSeconds);
  useEffect(() => {
    if (seconds <= 0) return;
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [seconds]);
  const formatted = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  return { seconds, formatted, setSeconds };
}
