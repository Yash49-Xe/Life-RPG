# Life Quest Chronicle

# PROMPT: Build a Premium Frontend for "Life RPG" Gamified Task Tracker

Act as a Principal Frontend Engineer & UI/UX Designer. Build a state-of-the-art, hyper-engaging, glassmorphic dark-mode web application frontend for **Life RPG** — a gamified productivity application where real-life task completion levels up your character, unlocks village building upgrades, maintains category streaks, and advances guild ranks.

---

## 🛠️ Tech Stack & Integration Specs

- **Framework**: Next.js (App Router) / React 19 + Tailwind CSS + Framer Motion.

- **Backend Architecture**: REST API routes hosted under `/api/*` and Supabase Auth.

- **API Response Structure**:

  - Success: `{ "data": { ... } }` (HTTP 200/201)

  - Error: `{ "error": "Detailed message" }` (HTTP 400/401/429/500)

---

## 🎮 Core Game Mechanics & Formulas

1. **Character Leveling**:

   - Non-linear XP threshold formula: `XP_required = Math.floor(100 * Math.pow(level, 1.5))`

   - XP Rewards by Category:

     - `Study / Focus`: +25 XP

     - `Exercise / Fitness`: +30 XP

     - `Work`: +20 XP

     - `Personal`: +15 XP

     - `Other`: +10 XP

   - *Note*: Verification failures or Gemini API fallbacks grant **50% partial XP** (status: `flagged`).

2. **Village Building Upgrade Queue**:

   - 4 Village Buildings: `Training Gym` (Fitness), `Grand Library` (Study), `Guild Office` (Work), `Art Studio` (Personal).

   - Building XP threshold: `Math.floor(80 * Math.pow(level, 1.4))`

   - Upgrade Duration: `targetLevel * 120` seconds (e.g. Level 2 upgrade takes 240 seconds).

   - Builder Queue Limit: **Fixed at 1 concurrent upgrade** across all buildings.

   - Ready State: Building status becomes `'ready'` when `current_xp >= xp_required_next`.

   - **Coin Rush (Fast-Forward)**: Reduces remaining upgrade time. Cost: `Math.ceil(seconds_remaining / 30) * 2` coins.

3. **Streaks & Currency**:

   - Coins Earned per task completion: `5 + Math.min(streak * 2, 20)` coins.

   - Streak Bonus: 3+ daily streak sets `streak_bonus_active = true`, awarding extra building XP (`Math.min(streak * 10, 50)`).

   - Streak Freeze: Preserves streak if a day is missed.

4. **Task Verification Rules**:

   - `Study / Focus` (Timer-based): Server verifies `NOW() - started_at >= min_duration_seconds`. Rejects early completions with HTTP 400.

   - `Exercise` (Photo AI): Accepts Base64 photo string, verified server-side via Gemini API. Rejections/timeouts fallback to `flagged` status & 50% partial XP.

   - `Gym` (GPS Location): Takes browser `latitude`, `longitude`, `accuracy` and validates location plausibility.

---

## 📡 API Endpoint Reference

### 🔐 Authentication

- `POST /actions/auth` (Server Actions for `login`, `register`, `logout`)

### 📋 Tasks API

- `GET /api/tasks` — List all user tasks.

- `POST /api/tasks` — Create task.

  - Body: `{ "title": "string", "category": "Study" | "Exercise" | "Gym" | "Work" | "Personal", "min_duration_seconds": 60 }`

- `DELETE /api/tasks/[id]` — Delete task.

- `POST /api/tasks/[id]/start` — Start timer session for Study/Gym tasks.

  - Body: `{ "minDurationSeconds": 60 }`

  - Returns: `{ "data": { "task": { ... }, "message": "Timer started" } }`

- `POST /api/tasks/[id]/complete` — Complete task & run verification pipeline.

  - Body (optional depending on verification type):

    ```json

    {

      "photoData": "data:image/jpeg;base64,...",

      "mimeType": "image/jpeg",

      "latitude": 37.7749,

      "longitude": -122.4194,

      "accuracy": 15

    }

    ```

  - Returns:

    ```json

    {

      "data": {

        "task": { "id": "...", "status": "completed", "verification_status": "verified" | "flagged" },

        "character": { "level": 2, "xp": 145 },

        "verification": { "type": "photo", "status": "verified", "isPartialXp": false, "reason": "Verified by Gemini" },

        "xpAwarded": 30,

        "leveledUp": true,

        "levelsGained": 1,

        "streak": { "current_streak": 4 },

        "building": { "id": "...", "current_xp": 80, "status": "ready" },

        "buildingBecameReady": true,

        "coinsEarned": 13,

        "totalCoins": 45

      }

    }

    ```

### 🏰 Village Buildings API

- `GET /api/buildings` — List 4 village buildings (auto-initializes defaults if empty).

- `POST /api/buildings/[id]/start-upgrade` — Start upgrade (requires `status === 'ready'`).

- `POST /api/buildings/[id]/complete-upgrade` — Finalize upgrade when timer reaches 0.

- `POST /api/buildings/[id]/rush` — Fast-forward upgrade timer using coins.

  - Returns: `{ "data": { "building": { ... }, "coinsRemaining": 30 } }`

### 🔥 Streaks API

- `GET /api/streaks` — List category streaks.

- `POST /api/streaks/[category]/freeze` — Consume streak freeze flag.

### 🎯 Daily Quests API

- `GET /api/quests` — Auto-assigns & fetches 3 daily quests for today.

- `POST /api/quests/[id]/complete` — Claim bonus XP for completed quest.

### ⚜️ Guilds & Leaderboard API

- `GET /api/leaderboard` — Top 50 global players (`user_id`, `display_name`, `level`, `xp`, `rank`).

- `GET /api/guilds` — Fetch user's current guild details.

- `POST /api/guilds` — Create a new guild. Body: `{ "name": "Iron Legion" }`. Returns `{ "guild": { "join_code": "X7K9P2", ... } }`.

- `POST /api/guilds/join` — Join a guild. Body: `{ "joinCode": "X7K9P2" }`.

- `GET /api/guilds/[id]/leaderboard` — Guild members leaderboard.

---

## 🎨 UI/UX Design Requirements for Lovable AI

1. **Dashboard Overview (`/`)**:

   - **Hero Card**: Character avatar, Level badge, non-linear XP progress bar to next level, coin balance.

   - **Upgrading Building Widget**: Live countdown timer (`MM:SS`), progress bar, and "⚡ Rush with Coins" button.

   - **Category Streaks**: Interactive streak cards with "❄️ Freeze Streak" option.

   - **Daily Quests Preview**: Quest cards with glowing `+30 XP` bonus badges.

2. **Village Architecture View (`/buildings`)**:

   - Visual 2D building grid with **Tiered Visual Progression**:

     - *Level 1-2*: Wooden Outpost / Hut

     - *Level 3-4*: Stone Manor / Academy

     - *Level 5+*: Grand Citadel / Arcane Tower

   - Displays building XP progress, `READY TO UPGRADE` glowing button, live construction queue timer, and coin rush option.

3. **Tasks & Quest Board (`/tasks`)**:

   - **Optimistic UI Updates**: Task completion immediately reflects in local state with animated rollback if server rejects.

   - **Verification Modals**:

     - *Study/Focus*: Live timer countdown with "▶️ Start Focus Session" and "Check & Complete" enforcer.

     - *Exercise*: Drag & drop photo upload preview for Gemini AI verification.

     - *Gym*: "📍 Get Browser Geolocation" button using `navigator.geolocation`.

4. **Character Sheet (`/character`)**:

   - Character avatar card, level badge, total XP formula breakdown.

   - **Attribute Radar / Stat Grid**: Strength (Fitness), Intelligence (Study), Endurance (Streaks), Creativity (Personal/Work).

5. **Guilds & Ranks (`/guild`)**:

   - **Global Ranks Tab**: Top 50 leaderboard table with Gold #1, Silver #2, Bronze #3 rank badges.

   - **Guild Center Tab**: Create Guild (generates join code), Join Guild (6-char code input), and Guild Member rankings.

6. **Micro-Interactions & Polish**:

   - **Level-Up Celebration**: Radiant burst modal (`LevelUpModal`) with confetti/halo effect when leveling up.

   - **Glassmorphic Styling**: Deep slate background (`#030712`), translucent panels (`backdrop-blur-xl bg-slate-900/80`), neon accents (cyan, amber, indigo, emerald).

   - **Accessibility**: Keyboard navigation, ARIA live region (`aria-live="polite"`), and clear focus indicators.
this is descricption and prompt of our backend for frontend make a attractive to positve vibe giving fronent of the site make a game grapics as much good as can make it identical to Clash of clans and minecraft

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/f416f474-d351-4e9a-a88d-2e82fa6a5f9a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
